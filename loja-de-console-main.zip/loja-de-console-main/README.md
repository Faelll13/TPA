Final project for Advanced Programming Techniques at Cotemig 

## License

The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
